module.exports = [
    {
      id: 1,
      name: "Ferritin Test",      
      image: "/images/gallery/ferritin_test_02.png",
    },
    {
      id: 2,
      name: "Bowel Health Test",      
      image: "/images/gallery/bowel_test_02.png",
    },
    {
      id: 3,
      name: "Covid Test",      
      image: "/images/gallery/covid_test_02.png",
    },
    {
      id: 4,
      name: "Vitamin D Test",      
      image: "/images/gallery/vitaminD_test_02.png",
    },
    {
      id: 5,
      name: "Thyroid Test",      
      image: "/images/gallery/thyroid_test_02.png",
    },
    {
      id: 6,
      name: "Male Fertility Test",      
      image: "/images/gallery/male_fertility_test_02.png",
    },
    {
      id: 7,
      name: "Menopause Test",      
      image: "/images/gallery/menopause_test_02.png",
    },
    {
      id: 8,
      name: "Ovulation Test",      
      image: "/images/gallery/ovulation_test_02.png",
    },
    {
      id: 9,
      name: "hCG Pregnancy Test",      
      image: "/images/gallery/hCG_pregnancy_test_02.png",
    },
    {
      id: 10,
      name: "Early Detection Pregnancy Test",      
      image: "/images/gallery/Early_pregnancy_test_02.png",
    },
    {
      id: 11,
      name: "Urinary Tract Infections Test",      
      image: "/images/gallery/urinary_test_02.png",
    },
    {
      id: 12,
      name: "Flowflex SARS-Cov-2 Test",      
      image: "/images/gallery/flowflex_test_02.png",
    },
]