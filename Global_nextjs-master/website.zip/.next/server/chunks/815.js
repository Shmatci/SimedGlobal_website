"use strict";
exports.id = 815;
exports.ids = [815];
exports.modules = {

/***/ 4815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);


const teamMembers = [
    {
        id: 1,
        name: "Simon Maurer",
        role: "Founder",
        imgSrc: "/images/team/Simon.jpg"
    },
    {
        id: 2,
        name: "Paul Cray",
        role: "Commercial",
        imgSrc: "/images/team/Paul.jpg"
    },
    {
        id: 3,
        name: "Dr Patrick Druggan",
        role: "Chief Scientific Officer",
        imgSrc: "/images/team/Patrick.jpg"
    },
    {
        id: 4,
        name: "Michael Marks",
        role: "Retail sales director",
        imgSrc: "/images/team/Michael.jpg"
    },
    {
        id: 5,
        name: "David Gould",
        role: "Director of Business Development",
        imgSrc: "/images/team/David.jpg"
    },
    {
        id: 6,
        name: "Ben Butterworth",
        role: "Director of Engineering",
        imgSrc: "/images/team/Ben.jpg"
    },
    {
        id: 7,
        name: "Tamara Vuksan",
        role: "Web Developer / Graphic Designer",
        imgSrc: "/images/team/Tammy.jpg"
    },
    {
        id: 8,
        name: "Amy Kelly",
        role: "Business Development Executive",
        imgSrc: "/images/team/Amy.jpg"
    },
    {
        id: 9,
        name: "Mahantesh Patil",
        role: "Machine Learning Engineer",
        imgSrc: "/images/team/Mahantesh.jpg"
    }
];
const Team = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: teamMembers.map((member)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-lg-3 col-sm-6",
                "data-aos": "fade-up",
                "data-aos-delay": `${member.id * 100}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "team-block-two mt-40",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "img-meta position-relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                width: 281,
                                height: 281,
                                src: member.imgSrc,
                                alt: member.name,
                                className: "lazy-img team-img w-100"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "info text-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "tx-dark fs-20 mb-5",
                                        children: member.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "tx-dark opacity-75",
                                        children: member.role
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, member.id))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Team);


/***/ })

};
;