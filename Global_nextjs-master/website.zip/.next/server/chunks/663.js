"use strict";
exports.id = 663;
exports.ids = [663];
exports.modules = {

/***/ 9663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_DefaulHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./data/menu.js
const pagesItems = [
    {
        title: "About Us",
        subItems: [
            {
                title: "About Us One",
                link: "/pages-menu/about-us-v1"
            },
            {
                title: "About Us Two",
                link: "/pages-menu/about-us-v2"
            }
        ]
    },
    {
        title: "Services",
        subItems: [
            {
                title: "Service One",
                link: "/pages-menu/service-v1"
            },
            {
                title: "Service Two",
                link: "/pages-menu/service-v2"
            },
            {
                title: "Service Three",
                link: "/pages-menu/service-v3"
            },
            {
                title: "Service Details",
                link: "/pages-menu/service-details"
            }
        ]
    },
    {
        title: "Our Team",
        subItems: [
            {
                title: "Team One",
                link: "/pages-menu/team-v1"
            },
            {
                title: "Team Two",
                link: "/pages-menu/team-v2"
            }
        ]
    },
    {
        title: "Other Pages",
        subItems: [
            {
                title: "FAQ",
                link: "/pages-menu/faq"
            },
            {
                title: "Signin",
                link: "/login"
            },
            {
                title: "Signup",
                link: "/signup"
            },
            {
                title: "404 Error",
                link: "/404"
            }
        ]
    }
];
const tttItems = [
    {
        name: "POC Blood Tests",
        link: "/ttt/poc"
    },
    {
        name: "EarWell",
        link: "https://www.earwellclinics.com",
        target: "_blank"
    },
    {
        name: "Self Health Tests",
        link: "/ttt/selfHealthTests"
    }
];
const navItems = [
    {
        label: "Home",
        submenuItems: [
            {
                title: "Insurance",
                link: "/"
            },
            {
                title: "Web Hosting",
                link: "/home/web-hosting"
            },
            {
                title: "Education",
                link: "/home/education"
            },
            {
                title: "N.P. Charity",
                link: "/home/charity"
            },
            {
                title: "Real Estate",
                link: "/home/real-estate"
            },
            {
                title: "Sass Product",
                link: "/home/sass-product"
            },
            {
                title: "App Landing",
                link: "/home/app-landing"
            },
            {
                title: "Crypto",
                link: "/home/crypto"
            },
            {
                title: "Personal Portfolio",
                link: "/home/personal-portfolio"
            },
            {
                title: "Agency Modern",
                link: "/home/agency-modern"
            },
            {
                title: "SEO & Digital Agency",
                link: "/home/seo"
            },
            {
                title: "Design Agency",
                link: "/home/design-agency"
            },
            {
                title: "Lead Generation",
                link: "/home/lead-generation"
            }
        ]
    },
    {
        title: "About Us",
        link: "/pages-menu/about-us-v1"
    },
    {
        title: "Service",
        link: "/pages-menu/service-v1"
    },
    {
        title: "Portfolio",
        link: "/portfolio/portfolio-v1"
    },
    {
        title: "Grid With sidebar",
        link: "/blog/blog-v2"
    },
    {
        title: "Contact us",
        link: "/contact"
    }
];

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/header/MainMenu.jsx





const MainMenu = ()=>{
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "navbar navbar-expand-lg order-lg-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "navbar-toggler d-block d-lg-none",
                type: "button",
                "data-bs-toggle": "collapse",
                "data-bs-target": "#navbarNav",
                "aria-controls": "navbarNav",
                "aria-expanded": "false",
                "aria-label": "Toggle navigation",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "collapse navbar-collapse",
                id: "navbarNav",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "navbar-nav",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "d-block d-lg-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "logo",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    className: "d-block",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/logo/main_logo.png",
                                        alt: "",
                                        width: 95,
                                        height: 40
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item dropdown mega-dropdown-md",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: "nav-link",
                                href: "/",
                                role: "button",
                                "data-bs-auto-close": "outside",
                                "aria-expanded": "false",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: "nav-link",
                                href: "/about",
                                role: "button",
                                "data-bs-auto-close": "outside",
                                "aria-expanded": "false",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "nav-item dropdown",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "nav-link dropdown-toggle",
                                    href: "/ttt",
                                    role: "button",
                                    "data-bs-auto-close": "outside",
                                    "aria-expanded": "false",
                                    children: "3T's"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "dropdown-menu",
                                    children: tttItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: item.link,
                                                className: "dropdown-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: item.name
                                                })
                                            })
                                        }, index))
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                className: "nav-link",
                                href: "/contact",
                                role: "button",
                                children: "Contact"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const header_MainMenu = (MainMenu);

;// CONCATENATED MODULE: ./components/header/DefaulHeader.jsx





const DefaulHeader = ()=>{
    const [navbar, setNavbar] = (0,external_react_.useState)(false);
    const changeBackground = ()=>{
        if (window.scrollY >= 10) {
            setNavbar(true);
        } else {
            setNavbar(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", changeBackground);
        return ()=>{
            window.removeEventListener("scroll", changeBackground);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: `theme-main-menu sticky-menu theme-menu-eight border-bottom ${navbar ? "fixed" : ""}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "inner-content position-relative",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex align-items-center justify-content-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "logo order-lg-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            className: "d-block",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/images/logo/main_logo.png",
                                alt: "logo",
                                width: 160,
                                height: 70
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(header_MainMenu, {})
                ]
            })
        })
    });
};
/* harmony default export */ const header_DefaulHeader = (DefaulHeader);


/***/ })

};
;