"use strict";
exports.id = 812;
exports.ids = [812];
exports.modules = {

/***/ 8812:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer_DefaultFooter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/footer/Footer2.jsx

const columns = [
    {
        title: "Links",
        links: [
            {
                label: "Home",
                url: "/"
            },
            {
                label: "About",
                url: "/about"
            },
            {
                label: "3T's",
                url: "/ttt"
            },
            {
                label: "Contact",
                url: "/contact"
            }
        ]
    },
    {
        title: "Tomorrow's Technology Today",
        links: [
            {
                label: "POC Blood Tests",
                url: "/ttt/poc"
            },
            {
                label: "EarWell",
                url: "https://www.earwellclinics.com"
            },
            {
                label: "Self Health Tests",
                url: "/ttt/selfHealthTests"
            }
        ]
    }
];
const Footer2 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: columns.map((column, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-xl-2 col-lg-3 col-sm-4 mb-30",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "footer-title tx-dark fw-normal",
                        children: column.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "footer-nav-link style-none",
                        children: column.links.map((link, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: link.url,
                                    children: link.label
                                })
                            }, index))
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const footer_Footer2 = (Footer2);

;// CONCATENATED MODULE: ./components/footer/NewsLetter.jsx

const NewsLetter = ()=>{
    const handleSubmit = (event)=>{
        event.preventDefault(); // prevent default form submission behavior
    // handle form submission logic
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        onClick: handleSubmit,
        className: "position-relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "email",
                placeholder: "Enter your email",
                required: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "tran3s fw-500 position-absolute",
                children: "Sign Up"
            })
        ]
    });
};
/* harmony default export */ const footer_NewsLetter = (NewsLetter);

;// CONCATENATED MODULE: ./components/footer/CopyrightFooter2.jsx


const icons = [
    {
        icon: "fab fa-facebook-f",
        href: "https://www.facebook.com/"
    },
    {
        icon: "fab fa-twitter",
        href: "https://www.twitter.com/"
    },
    {
        icon: "fab fa-linkedin-in",
        href: "https://www.linkedin.com/"
    }
];
const LinkItem = ({ title , href  })=>{
    return /*#__PURE__*/ _jsx("li", {
        children: /*#__PURE__*/ _jsx(Link, {
            href: href,
            children: title
        })
    });
};
const IconItem = ({ icon , href  })=>{
    return /*#__PURE__*/ _jsx("li", {
        children: /*#__PURE__*/ _jsx(Link, {
            href: href,
            target: "_blank",
            rel: "noopener noreferrer",
            children: /*#__PURE__*/ _jsx("i", {
                className: icon
            })
        })
    });
};
const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bottom-footer lg-pb-20 position-relative",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-4 order-lg-1 mt-15",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "copyright text-center m0",
                        children: [
                            "Copyright \xa9 ",
                            new Date().getFullYear(),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                style: {
                                    color: "inherit"
                                },
                                href: "https://themeforest.net/user/ib-themes",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: "Simed Global"
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const CopyrightFooter2 = (Footer);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/footer/DefaultFooter.jsx






const DefaultFooter = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-style-eleven theme-basic-footer position-relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-wrapper position-relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row justify-content-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 footer-intro mb-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "logo",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: "/images/logo/main_logo.png",
                                            alt: "brand",
                                            width: 160,
                                            height: 70
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer2, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-xl-4 col-lg-5 mb-30 form-widget",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "footer-title tx-dark fw-normal",
                                        children: "Newsletter"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        className: "pt-15 pb-20 md-pt-10",
                                        children: "Join our newsletter"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(footer_NewsLetter, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "fs-14 mt-10",
                                        children: "We only send interesting and relevant emails."
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CopyrightFooter2, {})
        ]
    });
};
/* harmony default export */ const footer_DefaultFooter = (DefaultFooter);


/***/ })

};
;