const DownArrow = () => {
    return (
    <>
        <meta charSet="utf-8" />
        <title>Scroll Indicator</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <div className="indicator" />
    </>
    )
}

export default DownArrow